<?php

    require_once 'head.php';
    require_once 'menu.php';
    ?>


    <div class="container-fluid">
        <div class="row">
            <div class="col-md">
                <h1>Nova Coleção</h1>
            </div>
        </div>
    </div>

    <?php
        require_once 'footer.php';
    ?>






<