<?php
  require_once 'head.php';
  require_once 'menu.php';

?>  



    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 text-center">
               <h1>Coleção 2023</h1>
            </div>

        </div>
    </div>
    

    <div class="container-fluid imagens">
        <div class="row">
            <div class="col-md-3">
                <div class="card" style="width: 18rem;">
                     <img class="card-img-top" src="imagens/roupa1.jpg" alt="Imagem de capa do card">
                     <div class="card-body">
                        <h3 class="card-text">Conjunto Mayra</h3>
                        <p class="card-text">R$ 50,00</p>
                        
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card" style="width: 18rem;">
                     <img class="card-img-top" src="imagens/roupa1.jpg" alt="Imagem de capa do card">
                     <div class="card-body">
                        <h3 class="card-text">Conjunto Mayra</h3>
                        <p class="card-text">R$ 50,00</p>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
            <div class="card" style="width: 18rem;">
                     <img class="card-img-top" src="imagens/roupa3.jpg" alt="Imagem de capa do card">
                     <div class="card-body">
                     <h3 class="card-text">Conjunto Mayra</h3>
                        <p class="card-text">R$ 50,00</p>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
            <div class="card" style="width: 18rem;">
                     <img class="card-img-top" src="imagens/roupa3.jpg" alt="Imagem de capa do card">
                     <div class="card-body">
                        <h3 class="card-text">Conjunto Mayra</h3>
                        <p class="card-text">R$ 50,00</p>
                    </div>
                </div>
            </div>

        </div>
    </div>

    

    <?php
        require_once 'footer.php';

    ?>
 





   